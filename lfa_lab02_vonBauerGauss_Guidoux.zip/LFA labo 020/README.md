Commandes à faire :

```
git clone https://github.com/Nortalle/LFA_lab021.git
cd LFA_lab021
conda create --name LFA_lab021 python=3.7
conda activate LFA_lab021
pip install -r requirements.txt
jupyter notebook
```

